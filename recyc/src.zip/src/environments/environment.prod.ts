export const environment = {
  firebase: {
    apiKey: "AIzaSyBTG-setzVBe8c-xyc3SMqkRMJqY2stb3g",
    authDomain: "proiect-isi-recyc.firebaseapp.com",
    projectId: "proiect-isi-recyc",
    storageBucket: "proiect-isi-recyc.appspot.com",
    messagingSenderId: "101532237497",
    appId: "1:101532237497:web:86ccb559798df28632e568",
    measurementId: "G-0X9ZF6F8XG"
  },
  production: true
};
  